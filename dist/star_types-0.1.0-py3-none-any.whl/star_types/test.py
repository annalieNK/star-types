import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.compose import make_column_selector as selector
from sklearn.compose import make_column_transformer
from sklearn.model_selection import GridSearchCV
import sklearn.metrics as metrics
from sklearn.metrics import roc_auc_score, roc_curve, auc, precision_recall_curve, plot_confusion_matrix, confusion_matrix, accuracy_score
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import label_binarize
from sklearn.preprocessing import LabelBinarizer
from sklearn.multiclass import OneVsRestClassifier
import matplotlib.pyplot as plt
from itertools import cycle
import seaborn as sns
import json
import io
import pickle

import plots


df = pd.read_csv('data/data.csv')
df['Star color'] = df['Star color'].apply(lambda x: x.strip())

# preprocessor = preprocess()

X = df[df.columns[:-1]]
y = df['Spectral Class'].tolist()

# le = LabelEncoder()
# le.fit(y)
# y = le.transform(y) 

# y = label_binarize(y, classes=[0, 1, 2, 3, 4, 5, 6])
# n_classes = y.shape[1]

# lb = LabelBinarizer()
# y = lb.fit_transform(y)
# n_classes = y.shape[1]

# convert categorical column to dummy variable
numeric_features = ['Temperature (K)', 'Luminosity(L/Lo)', 'Radius(R/Ro)',
                   'Absolute magnitude(Mv)', 'Star type']
numeric_transformer = StandardScaler()

categorical_features = ['Star color']
categorical_transformer = OneHotEncoder(handle_unknown='ignore') #sparse=False, drop="first"

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, selector(dtype_include="number")),#numeric_features),
        ('cat', categorical_transformer,  selector(dtype_include=object))],#categorical_features)])
    remainder='passthrough')

# preprocessor = make_column_transformer((OneHotEncoder(), ['Star color']),#selector(dtype_include=object)),
#                                         remainder='passthrough')

# # Append classifier to preprocessing pipeline.
# clf = Pipeline(steps=[('preprocessor', preprocessor),
#                       ('classifier', OneVsRestClassifier(LogisticRegression()))])#RandomForestClassifier

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2,
                                                    random_state=0)

# clf.fit(X_train, y_train)

# param_grid = {
#     'classifier__estimator__C': [0.1, 1.0, 10],
# }
# param_grid = {
#     'classifier__n_estimators': [50, 100],
#     'classifier__max_features' :['sqrt', 'log2'],
#     'classifier__max_depth' : [4,6,8],
#     }


names = [
        "Logistic Regression",
         "Random Forest",
         "Support Vector Machine",
         "KNeighbors"
        ]

classifiers = [
            LogisticRegression(),
            RandomForestClassifier(),
            SVC(),
            KNeighborsClassifier()
            ]

# # Create a pipeline
# clf = Pipeline(steps=[('preprocessor', preprocessor),
#                       ('classifier', LogisticRegression())
#                       ]
#               )

# print(pipe.get_params().keys())

# Create space of candidate learning algorithms and their hyperparameters
param_grid = [
            {'classifier': [LogisticRegression()],
            'classifier__C': [0.1, 1.0, 10]},
            {'classifier': [RandomForestClassifier()],
            'classifier__n_estimators': [50, 100],
            'classifier__max_features' :['sqrt', 'log2'],
            'classifier__max_depth': [4,6,8]},
            {'classifier': [SVC()],
            'classifier__C': [0.1, 1.0, 10],
            'classifier__kernel': ['linear'],
            'classifier__probability': [True]},
            {'classifier': [KNeighborsClassifier()],
            'classifier__n_neighbors': [3, 5],
            'classifier__weights': ['uniform', 'distance']}
            ]

output_cols = ["Classifier", "Accuracy", "Best parameters"]
output = pd.DataFrame(columns=output_cols)

# Create grid search 
for name, classifier, params in zip(names, classifiers, param_grid):
    clf_pipe = Pipeline(steps=[
                                ('preprocessor', preprocessor),
                                ('classifier', OneVsRestClassifier(LogisticRegression()))
                                ]
                        )
    gs_clf = GridSearchCV(clf_pipe, param_grid=params, cv=5, verbose=0, n_jobs=-1)
    clf = gs_clf.fit(X_train, y_train)
    score = accuracy_score(y_test, clf.predict(X_test))#clf.score(X_test, y_test)
    print(score)
    best_parameters = clf.best_estimator_.get_params()['classifier']
    # print("{} score: {}".format(name, score))
    # print(clf.best_estimator_.get_params()['classifier'])
    # print(name)
    # print(score)
    # print(clf.best_estimator_.get_params()['classifier'])
    # d = {'model type': name,
    #         'score': score,
    #         # 'best parameters': clf.best_estimator_.get_params()['classifier']
    #         }
    # print(d)

    output_entry = pd.DataFrame([[name, score, best_parameters]], columns=output_cols)
    output = output.append(output_entry, ignore_index=True)

# output.to_csv('reports/scores.csv')
print(output) 
    # with open('reports/scores.json', 'w') as fd:
    #     json.dump(d, fd)
#     with io.open('reports/scores.pkl', 'wb') as fd_out:
#         pickle.dump(d, fd_out)

# with open('reports/scores.pkl', 'rb') as fd:
#     df = pickle.load(fd)

# print(df)

# # grid_search = GridSearchCV(clf, param_grid, cv=10)
# grid_search = GridSearchCV(clf, param_grid, cv=5, verbose=0)

# # Fit grid search
# # grid_search.fit(X_train, y_train)
# best_model = grid_search.fit(X_train, y_train)

# # View best model
# print(best_model.best_estimator_.get_params()['classifier'])




# print("model score: %.3f" % clf.score(X_test, y_test))
# print(grid_search.best_params_)
# print(grid_search.score(X_test, y_test))   


# # # ROC AUC score
# predictions = grid_search.predict_proba(X_test)

# Binarize the output
# y_test_binarized = label_binarize(y_test, classes=[0, 1, 2, 3, 4, 5, 6])
# n_classes = y_test_binarized.shape[1]
# print(roc_auc_score(y_test_binarized, predictions, multi_class='ovr'))

# lb = LabelBinarizer()
# y_test_binarized = lb.fit_transform(y_test)
# print(y_test_binarized.shape)
# print(roc_auc_score(y_test, predictions, multi_class='ovr'))

# predictions = grid_search.decision_function(X_test)
# n_classes = y_test.shape[1]

# print(lb.inverse_transform(y_test)[:5])
# fpr = dict()
# tpr = dict()
# roc_auc = dict()
# for i in range(n_classes):
    # fpr[i], tpr[i], threshold = roc_curve(y_test[:, i], predictions[:, i])
    # roc_auc[i] = auc(fpr[i], tpr[i])

# plot_roc_auc.roc_auc_multiclass(grid_search, X_test, n_classes, y_test)

# # print(metrics.classification_report(y_test, predictions, labels=[0,1,2,3,4,5,6]))
# import csv

# with open('predicted.csv', 'w') as f:
#     writer = csv.writer(f)
#     writer.writerow(["actual", "predicted"])
#     writer.writerows(zip(y_test, predictions)) 

# confusion_matrix = plot_confusion_matrix(
#                             grid_search, 
#                             X_test, lb.inverse_transform(y_test),
#                             cmap=plt.cm.Blues
#                             )
# # with open(confusion_matrix_plots_file, 'w') as fd:
# #     plt.savefig(fd)
# plt.savefig('confusion_matrix.png')

# predictions = grid_search.predict(X_test)

# with open(confusion_matrix_plots_file, 'w') as fd:
#     plots.confusion_matrix_plot(lb.inverse_transform(y_test), lb.inverse_transform(predictions), lb.classes_)
#     plt.savefig(fd)

